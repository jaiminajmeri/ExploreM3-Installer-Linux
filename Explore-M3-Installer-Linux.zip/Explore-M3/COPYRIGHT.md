Copyright (c) 2016 ExploreEmbedded.com
All Rights Reserved.

Explore Embedded reserves rights to all the all orginal work done in the development of Explore M3. We may eventually release the work under
a open source license. However all rights will be reserved. Explore Embedded will decide about opening up the work under a opensource license
at the end of crowdfunding campaign. 

The copyright notice is to protect our interests in time and effort involved during the development. By using the contents of the repository, you
agree with the copyright notice. For all the additional work that you will be contributing please add the author name as your name only. 
